<?php
    class SubClasse extends SuperClasse {
        public function calcular() {
            echo "<p>Método calcular da SubClasse";
        }
    }