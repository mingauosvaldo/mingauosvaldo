<?php
    class SuperClasse {
        public function imprimir() {
            echo "<p>Método imprimir da SuperClasse";
        }
    }