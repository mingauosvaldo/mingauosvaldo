<?php
    // Incluir os arquivos das classes
    require "SuperClasse.php";
    require "SubClasse.php";

    // Instanciar um objeto da SubClasse
    $objSub = new SubClasse();
    $objSub->imprimir();
    $objSub->calcular();